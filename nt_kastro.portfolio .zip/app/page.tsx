'use client'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

interface Project {
  id: string
  title: string
  category: string
  media_url: string
  media_type: 'image' | 'video'
  description: string
}

interface SiteSettings {
  tagline: string
  about_text: string
  contact_email: string
  instagram_url: string
  showreel_url: string
}

export default function Home() {
  const [projects, setProjects] = useState<Project[]>([])
  const [settings, setSettings] = useState<SiteSettings>({
    tagline: 'DANCER · PERFORMER · CHOREOGRAPHER',
    about_text: 'Profissional de dança e performance especializado em estilos urbanos e acrobáticos.',
    contact_email: 'contato@natanaelcastro.com',
    instagram_url: 'https://instagram.com',
    showreel_url: '#'
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchData()
  }, [])

  async function fetchData() {
    try {
      const { data: projData } = await supabase.from('portfolio_items').select('*').order('created_at', { ascending: false })
      if (projData) setProjects(projData)

      const { data: settData } = await supabase.from('site_settings').select('*').single()
      if (settData) setSettings(settData)
    } catch (error) {
      console.error('Erro ao carregar dados:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-[#0b0b0e] text-white px-6 py-12 max-w-6xl mx-auto">
      {/* Header / Hero */}
      <header className="flex justify-between items-center mb-16 border-b border-zinc-800 pb-6">
        <h2 className="text-xl font-bold tracking-widest uppercase">
          <span className="font-sans">N</span><span className="font-gothic text-2xl lowercase">atanael Castro</span>
        </h2>
        <a href="/login" className="text-xs uppercase tracking-widest px-4 py-2 border border-zinc-700 rounded-full hover:bg-white hover:text-black transition">
          Admin Login
        </a>
      </header>

      <section className="text-center my-20">
        <p className="text-xs tracking-[0.3em] text-zinc-400 mb-4">{settings.tagline}</p>
        <h1 className="text-5xl md:text-7xl font-black tracking-tight mb-8">NT CASTRO</h1>
        {settings.showreel_url && settings.showreel_url !== '#' && (
          <a href={settings.showreel_url} target="_blank" rel="noopener noreferrer" className="inline-block bg-white text-black font-bold px-8 py-4 rounded-full text-sm tracking-wider hover:bg-zinc-200 transition">
            ▶ ASSISTIR SHOWREEL
          </a>
        )}
      </section>

      {/* Grid Cinematográfica de Projetos */}
      <section className="my-24">
        <h3 className="text-xs font-bold tracking-[0.2em] text-zinc-500 uppercase mb-8">Selected Work</h3>
        {loading ? (
          <p className="text-center text-zinc-500">Carregando portfólio...</p>
        ) : projects.length === 0 ? (
          <p className="text-center text-zinc-600 border border-dashed border-zinc-800 py-12 rounded-xl">Nenhum projeto cadastrado ainda.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {projects.map((p) => (
              <div key={p.id} className="group relative bg-zinc-900 rounded-xl overflow-hidden border border-zinc-800">
                <div className="h-80 w-full overflow-hidden bg-black">
                  {p.media_type === 'video' ? (
                    <video src={p.media_url} controls className="w-full h-full object-cover" />
                  ) : (
                    <img src={p.media_url} alt={p.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />
                  )}
                </div>
                <div className="p-6">
                  <span className="text-[10px] uppercase tracking-widest text-zinc-400">{p.category}</span>
                  <h4 className="text-xl font-bold mt-1">{p.title}</h4>
                  <p className="text-sm text-zinc-400 mt-2">{p.description}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* About */}
      <section className="my-24 max-w-2xl mx-auto text-center border-t border-zinc-800 pt-16">
        <h3 className="text-xs font-bold tracking-[0.2em] text-zinc-500 uppercase mb-6">About The Artist</h3>
        <p className="text-zinc-300 leading-relaxed text-lg">{settings.about_text}</p>
      </section>

      {/* Contact */}
      <footer className="mt-32 border-t border-zinc-800 pt-12 text-center pb-12">
        <h3 className="text-xs font-bold tracking-[0.2em] text-zinc-500 uppercase mb-6">Contact</h3>
        <a href={`mailto:${settings.contact_email}`} className="text-2xl md:text-3xl font-light hover:underline block mb-8">{settings.contact_email}</a>
        <div className="flex justify-center gap-6">
          <a href={settings.instagram_url} target="_blank" rel="noopener noreferrer" className="text-sm uppercase tracking-widest text-zinc-400 hover:text-white">Instagram</a>
        </div>
      </footer>
    </main>
  )
}
