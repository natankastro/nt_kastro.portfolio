'use client'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useRouter } from 'next/navigation'

export default function AdminPage() {
  const [loading, setLoading] = useState(true)
  const [title, setTitle] = useState('')
  const [category, setCategory] = useState('')
  const [description, setDescription] = useState('')
  const [mediaType, setMediaType] = useState<'image' | 'video'>('image')
  const [file, setFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)
  const router = useRouter()

  useEffect(() => {
    checkUser()
  }, [])

  async function checkUser() {
    const { data: { session } } = await supabase.auth.getSession()
    if (!session) {
      router.push('/login')
    } else {
      setLoading(false)
    }
  }

  async function handleAddProject(e: React.FormEvent) {
    e.preventDefault()
    if (!file) return alert('Selecione um arquivo de foto ou vídeo.')

    setUploading(true)
    try {
      const fileExt = file.name.split('.').pop()
      const fileName = `${Math.random()}.${fileExt}`
      const filePath = `${fileName}`

      const { error: uploadError } = await supabase.storage.from('portfolio').upload(filePath, file)
      if (uploadError) throw uploadError

      const { data: { publicUrl } } = supabase.storage.from('portfolio').getPublicUrl(filePath)

      const { error: dbError } = await supabase.from('portfolio_items').insert([
        { title, category, description, media_type: mediaType, media_url: publicUrl }
      ])

      if (dbError) throw dbError

      alert('Projeto adicionado com sucesso!')
      setTitle('')
      setCategory('')
      setDescription('')
      setFile(null)
    } catch (err: any) {
      alert('Erro ao enviar: ' + err.message)
    } finally {
      setUploading(false)
    }
  }

  async function handleLogout() {
    await supabase.auth.signOut()
    router.push('/login')
  }

  if (loading) return <div className="min-h-screen bg-[#0b0b0e] text-white flex items-center justify-center">Verificando acesso...</div>

  return (
    <div className="min-h-screen bg-[#0b0b0e] text-white p-6 max-w-2xl mx-auto">
      <div className="flex justify-between items-center mb-8 border-b border-zinc-800 pb-4">
        <h1 className="text-xl font-bold">Painel Administrativo</h1>
        <button onClick={handleLogout} className="text-xs bg-red-500/10 text-red-400 border border-red-500/20 px-4 py-2 rounded-lg">Sair</button>
      </div>

      <form onSubmit={handleAddProject} className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl space-y-4">
        <h2 className="text-lg font-bold mb-4">Adicionar Novo Projeto</h2>
        <div>
          <label className="block text-xs uppercase text-zinc-400 mb-1">Título</label>
          <input type="text" value={title} onChange={e => setTitle(e.target.value)} required className="w-full p-3 bg-zinc-950 border border-zinc-800 rounded-lg" />
        </div>
        <div>
          <label className="block text-xs uppercase text-zinc-400 mb-1">Categoria</label>
          <input type="text" value={category} onChange={e => setCategory(e.target.value)} required placeholder="Ex: Breaking / Performance" className="w-full p-3 bg-zinc-950 border border-zinc-800 rounded-lg" />
        </div>
        <div>
          <label className="block text-xs uppercase text-zinc-400 mb-1">Tipo de Mídia</label>
          <select value={mediaType} onChange={e => setMediaType(e.target.value as 'image' | 'video')} className="w-full p-3 bg-zinc-950 border border-zinc-800 rounded-lg">
            <option value="image">Foto</option>
            <option value="video">Vídeo</option>
          </select>
        </div>
        <div>
          <label className="block text-xs uppercase text-zinc-400 mb-1">Arquivo da Galeria</label>
          <input type="file" onChange={e => setFile(e.target.files?.[0] || null)} required className="w-full p-3 bg-zinc-950 border border-zinc-800 rounded-lg text-sm text-zinc-400" />
        </div>
        <div>
          <label className="block text-xs uppercase text-zinc-400 mb-1">Descrição</label>
          <textarea value={description} onChange={e => setDescription(e.target.value)} className="w-full p-3 bg-zinc-950 border border-zinc-800 rounded-lg h-24" />
        </div>
        <button type="submit" disabled={uploading} className="w-full bg-white text-black font-bold py-3 rounded-lg hover:bg-zinc-200 transition">
          {uploading ? 'Enviando para nuvem...' : 'Publicar Projeto'}
        </button>
      </form>
    </div>
  )
}
