import './globals.css'
import type { Metadata } from 'node_modules/next'

export const metadata: Metadata = {
  title: 'Natanael Castro | Professional Dancer',
  description: 'Portfólio profissional de dança, performance e coreografia.',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR">
      <head>
        <link href="https://fonts.googleapis.com/css2?family=UnifrakturMaguntia&display=swap" rel="stylesheet" />
      </head>
      <body>{children}</body>
    </html>
  )
}
