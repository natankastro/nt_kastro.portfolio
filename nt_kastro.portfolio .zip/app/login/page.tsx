'use client'
import { useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useRouter } from 'next/navigation'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const router = useRouter()

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) {
      setError('Credenciais inválidas.')
    } else {
      router.push('/admin')
    }
  }

  return (
    <div className="min-h-screen bg-[#0b0b0e] flex items-center justify-center px-4">
      <form onSubmit={handleLogin} className="bg-zinc-900 border border-zinc-800 p-8 rounded-2xl w-full max-w-md">
        <h2 className="text-2xl font-bold mb-6 text-center">Painel Admin</h2>
        {error && <p className="text-red-500 text-xs mb-4 text-center">{error}</p>}
        <div className="mb-4">
          <label className="block text-xs uppercase tracking-wider text-zinc-400 mb-2">E-mail</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="w-full p-3 bg-zinc-950 border border-zinc-800 rounded-lg text-white" />
        </div>
        <div className="mb-6">
          <label className="block text-xs uppercase tracking-wider text-zinc-400 mb-2">Senha</label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required className="w-full p-3 bg-zinc-950 border border-zinc-800 rounded-lg text-white" />
        </div>
        <button type="submit" className="w-full bg-white text-black font-bold py-3 rounded-lg tracking-wider text-sm hover:bg-zinc-200 transition">ENTRAR</button>
      </form>
    </div>
  )
}
